This package contains 2 BIOS modifications for Lenovo ThinkPad X220 laptop.

** Lenovo X220 v1.46 Modified Bios (no whitelist only) **

- Whitelist removal only
- Re-signed with custom key to get rid of 5 beeps on boot

** Lenovo X220 v1.46 Modified Bios (full-blown) **

- Whitelist removal
- Unlocked AES-NI on "no-encryption" machines
- Unlocked hidden advanced menu
- Unlocked memory speed (supports DDR3 1600 and 1866)
- Disabled package c-state lock at MSR 0xE2 (for Hackintosh)
- Re-signed with custom key to get rid of 5 beeps on boot

Be careful with advanced menu. Changing some options may render your laptop unbootable!
More memory speed means more heat, 1866 MHz memory speed may increase your laptop temperature up to 5°C.

To flash the BIOS, run "WINUPTP.EXE" from one of the modified BIOS folder. No need to flash original BIOS image prior to flashing modified one.
If you on 1.46 already, use "flash.bat" to flash.

These modifications were made by camiloml, BDMaster, Serg008, Oleh/Rambler and others. I'm (ValdikSS) only created hash recomputation and re-signing script and keep backporting all modifications from older to newer BIOS versions.

In case you're interested in re-signing script:
https://github.com/ValdikSS/thinkpad-shahash

---------------

ValdikSS
